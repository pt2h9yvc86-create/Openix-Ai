// EDIT HERE: add/remove services. category must match a chip.
const SERVICES=[
 {cat:'Cloning',name:'Website cloner',desc:'Paste a URL, get editable React code.',tag:'AI'},
 {cat:'Cloning',name:'Style extraction',desc:'Fonts, palettes and scenes as design tokens.',tag:'AI'},
 {cat:'Builds',name:'App builder',desc:'Templates to working app, with live preview.',tag:'Web'},
 {cat:'Builds',name:'Mobile builds',desc:'React Native / Expo specs and screens.',tag:'Mobile'},
 {cat:'Prompts',name:'Prompt generator',desc:'Idea to build-ready prompt with version history.',tag:'AI'},
 {cat:'Prompts',name:'Flow charts',desc:'Visualize app logic before coding.',tag:'Docs'},
 {cat:'Support',name:'Deploy & hosting',desc:'One-click deploy, SSL, CDN, scaling.',tag:'Ops'},
 {cat:'Support',name:'Customization',desc:'Colors, text and layout changes on request.',tag:'Service'}
];
const cats=['All',...new Set(SERVICES.map(s=>s.cat))];
const chips=document.getElementById('chips'),grid=document.getElementById('grid');
function draw(c){
 chips.innerHTML=cats.map(x=>`<button class="chip ${x===c?'on':''}" data-c="${x}">${x}</button>`).join('');
 grid.innerHTML=SERVICES.filter(s=>c==='All'||s.cat===c).map(s=>`<div class="c"><div class="m">${s.cat}</div><h3>${s.name}</h3><p>${s.desc}</p><span class="tag">${s.tag}</span></div>`).join('');
}
chips.onclick=e=>{if(e.target.dataset.c)draw(e.target.dataset.c)};
draw('All');
