
var g=document.getElementById('go'),l=document.getElementById('log'),t;
g.onclick=function(){clearTimeout(t);var s=['Fetching '+document.getElementById('u').value,'Extracting structure + colors','Generating React components','<b>✓ Preview ready (demo)</b>'],i=0;l.innerHTML='';(function n(){if(i<s.length){l.innerHTML+=s[i++]+'<br>';t=setTimeout(n,600)}})()};
