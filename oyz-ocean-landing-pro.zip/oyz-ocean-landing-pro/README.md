# OYZ Ocean — Landing Page Pro

Static, production-ready HTML/CSS/JS. No build step.

## Files
- `index.html` landing page (hero, features, flow, plans, FAQ)
- `catalog.html` filterable service catalog
- `design-system.html` colors, type, buttons
- `css/tokens.css` **edit colors and fonts here**
- `css/main.css` layout and components
- `js/catalog.js` **edit services/categories here**
- `js/main.js` clone-demo animation (demo only)

## Customize
1. Change `--lime`, `--bg`, etc. in `css/tokens.css`.
2. Replace text directly in the HTML files.
3. Set real prices in `index.html` (`$—` placeholders).

## Deploy
Upload the folder to Netlify, Vercel, GitHub Pages or any web host.
Requires internet for Google Fonts (or self-host the fonts).
